<?php

require_once '../../utils/utils.php';
require_once '../../utils/database.php';


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    return; 
}

/* if(!isTokenValid()){
    echo json_encode("{success: false, status: \"invalid token\"}");
    die();
    return;
} */

//Run your messages code here

if (!isset($_POST['description']) || !isset($_POST['room_id']) || !isset($_POST['student_number'])) {
    http_response_code(400);
    return; 
}

$conn = connectDatabase();

$queryUserId = $conn->prepare("SELECT id FROM users where number = :student_number"); 
$queryUserId->bindParam(":student_number", $_POST["student_number"]);
$queryUserId->execute();

$queryUserId->setFetchMode(PDO::FETCH_ASSOC);
$result = $queryUserId ->fetchAll();


 
$stmt = $conn->prepare("INSERT INTO messages (description, room_id, user_id) VALUES (:description, :room_id, :user_id)"); 
$stmt->bindParam(':description', $_POST['description']); 
$stmt->bindParam(':room_id', $_POST['room_id']); 
$stmt->bindParam(':user_id', $result[0]["id"]); 

$stmt->execute();   
//echo json_encode("{success: true}");
?>
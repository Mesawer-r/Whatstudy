/**
 * Call to load the test messages.
 */

var tokenRequest = "";
var studentNummer;
var roomId = 1;

document.addEventListener('click', function(event){

    var target = event.target;
    console.log(target);


    if(target.classList.contains('roomItem')){
        var id = target.id;
        roomId = id;
        document.getElementById("displayroom").innerHTML = '<div class="badge badge-primary">Current room:' + target.innerHTML+ '</div>';
        console.log(target.innerHTML);
        loadTestMessages();

    }

});


function loadTestMessages() {
    var request = new XMLHttpRequest();

    request.open('GET', 'api/rooms/'+roomId+'/messages?token='+ tokenRequest , true );    
//    request.open('GET', 'https://ori.clow.nl/ori2/testmessages.json', true);
    request.onload = function()
    
    {
        if (request.status === 200) {
            var messages = JSON.parse(request.response);
            // console.log(messages);
            messages.sort((a,b)=>{
                // console.log(a);
                return new Date(a.created_at)-new Date(b.created_at);
            });
            showMessages(messages);
        } else {
            document.getElementById("messages").innerHTML = 'je bent niet ingelogd op epic. log in op '  + '<a href="https://epic.clow.nl/">Epic</a> om binnen te komen';
            document.getElementById("inputtext").style.display="none";
            document.getElementById("submit").style.display="none";
        }
    };
    
    request.onerror = function() {
        console.error("could not load messages");
    };

    request.send();
}

/**
 * Display the given messages
 * @param {Array} messages 
 */


 //Control rooms 
//hiermee worden de berichten geladen door middel van ForEach zodat alles wat in de arrays staat wordt weergeven.
function showMessages(messages){
    //messages = Object.values(messages);
    document.getElementById("messages").innerHTML = "";
    messages.forEach(function(message) {
        var message = "<div class='container'> <i class= 'fa fa-user'> <p id='textweergave'>" + message.first_name +": " +message.description + " " + message.created_at;
        
        document.getElementById("messages").innerHTML += message;
    }
)}

/**
 * Get token from Epic and call function tokenReceived when done
 */
function getToken() {
    var s = document.createElement("script");
    s.src = "https://epic.clow.nl/token?callback=tokenReceived";
    document.body.appendChild(s);
    
}   

/**
 * Determine whether a valid token or an error is received
 */ 
function tokenReceived(token) {
    // console.log('Token received:', token);
    tokenRequest = token.token;
    // Load the messages
    document.getElementById("displayroom").innerHTML = '<div class="badge badge-primary">Current room:Public</div>';
    loadTestMessages();
    getrooms();
    setInterval(function(){ loadTestMessages(); }, 3000);
    firstName = token.name.first;
    studentNummer = token.id;
    document.getElementById("nameMain").innerHTML = 'hi' +  " " +  firstName + " " +  "Studentnummer: " + studentNummer;

}


function postmessage() {
        var http = new XMLHttpRequest();
    // console.log("send token", tokenRequest);
    var url = 'api/messages?token=' + tokenRequest;
    // console.log("url", url);
    var params = 'room_id='+ roomId + '&description=' + document.getElementById("inputtext").value + '&student_number=' + studentNummer;
    // console.log("params",params);   
    http.open('POST', url, false);

//Send the proper header information along with the request
http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

http.onreadystatechange = function() {//Call a function when the state changes.
    if(http.readyState == 4 && http.status == 200) {
        loadTestMessages();
    }
}
http.send(params);
document.getElementById("inputtext").value = "";
}; 


document.getElementById("submit").onclick = postmessage;


function showRooms(rooms){

    var $rooms = document.getElementById("rooms");
    $rooms.innerHTML = "";
    rooms.forEach(function(room) {
        var roomHtml = '<div class="roomItem m-1 d-inline-block" id="'+room.id+'">'+room.name+'</div>';
        $rooms.innerHTML += roomHtml; 
    });
}

// And don't forget to call getToken()
function getrooms() {
    var request = new XMLHttpRequest();

    request.open('GET', 'api/rooms?token='+ tokenRequest , true );    
    request.onload = function()
    
    {
        if (request.status === 200) {
            var rooms = JSON.parse(request.response);
            rooms.sort((a,b)=>{
                // console.log(a);
                return new Date(a.created_at)-new Date(b.created_at);
            });
            showRooms(rooms);
        } else {
            document.getElementById("Chatinsertbox").style.display="none";
        }
    };
    
    request.onerror = function() {
        console.error("could not load rooms");
    };

    request.send();
}

getToken();
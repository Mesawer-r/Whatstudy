<?php 

require_once '../../config/settings.php';
require_once "utils.php";

function connectDatabase(){

    $uri = explode('/api/', $_SERVER['REQUEST_URI']);
    //$uri == 'rooms/1/messages' && getHTTPResponseStatusCode($url) ? getMessages($conn) : http_response_code(401); die();

    try {
        $conn = new PDO(
            "mysql:host=" .DB_SERVER.";dbname=".DB_NAME.";charset=UTF8",
            DB_USERNAME,
            DB_PASSWORD
            );
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo"connected succesfully";
    }catch (PDOException $e) {
        echo "connection Failed: " . $e->getMessage();
    } 

    

    return $conn;
}
?>
<?php
function getHTTPResponseStatusCode($url)
{
    $status = null;

    $headers = @get_headers($url, 1);
    if ($headers === false) return false; // when server not found
    foreach($headers as $header) { // parse all headers:
      // corrects $url when 301/302 redirect(s) lead(s) to 200:
      if(preg_match("/^Location: (http.+)$/",$header,$m)) $url=$m[1];
      // grabs the last $header $code, in case of redirect(s):
      if(preg_match("/^HTTP.+\s(\d\d\d)\s/",$header,$m)) $code=$m[1];
    } // End foreach...

    if($code==200) return true; // $code 200 == all OK
    else return false; // All else has failed, so this must be a bad link
}

/**
 * Returns true if token is valid and false if token is invalid or url is invalid
 */
/* function isTokenValid(){  

  if(isset($_GET['token'])) {
    
    $loginToken = $_GET['token'];
    $url = 'https://epic.clow.nl/token/check/'. $loginToken;

    $response = getHTTPResponseStatusCode($url);

    $uri = explode('/api/', $_SERVER['REQUEST_URI']);
    if(isset($uri[1])){
      $uri = $uri[1];
      $uri = explode('?',$uri);
      $uri = $uri[0];
    }
    if(($uri == "rooms/1/messages" || $uri == "messages.php" || "rooms") && $response == true){
      return true;
    }
    
  }

  return false;
}
 */
?>